# Whale Tracker Bot

Bu Telegram bot whale (kotta wallet) tranzaksiyalarni kuzatish uchun.